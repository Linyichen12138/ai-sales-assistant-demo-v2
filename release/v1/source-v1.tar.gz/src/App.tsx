import { useEffect } from 'react'
import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { DemoBar, GuidePanel } from './components/DemoBar'
import { useDemo } from './store/demo'
import C01 from './pages/phone/C01'
import C02 from './pages/phone/C02'
import C03 from './pages/phone/C03'
import C10 from './pages/phone/C10'
import C04 from './pages/phone/C04'
import C04Summary from './pages/phone/C04Summary'
import C06 from './pages/phone/C06'
import C05 from './pages/phone/C05'
import Me from './pages/phone/Me'
import S01 from './pages/shared/S01'
import M01 from './pages/pc/M01'
import M02 from './pages/pc/M02'
import M03 from './pages/pc/M03'
import M04 from './pages/pc/M04'
import M05 from './pages/pc/M05'
import ScreenC02 from './pages/pc/ScreenC02'

function Home() {
  const role = useDemo((s) => s.role)
  return <Navigate to={role === 'manager' ? '/m01' : '/c01'} replace />
}

/** 直接访问某端页面时，同步全局角色（保持演示栏一致） */
function RoleSync() {
  const loc = useLocation()
  useEffect(() => {
    const p = loc.pathname
    const s = useDemo.getState()
    if (p.startsWith('/m') && p !== '/me' && s.role !== 'manager') s.set({ role: 'manager' })
    if ((p.startsWith('/c') || p === '/me') && s.role !== 'consultant') s.set({ role: 'consultant' })
    window.scrollTo(0, 0)
  }, [loc.pathname])
  return null
}

export default function App() {
  return (
    <div className="app">
      <DemoBar />
      <RoleSync />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/c01" element={<C01 />} />
        <Route path="/c02" element={<C02 />} />
        <Route path="/c03" element={<C03 />} />
        <Route path="/c10" element={<C10 />} />
        <Route path="/c04" element={<C04 />} />
        <Route path="/c04/summary" element={<C04Summary />} />
        <Route path="/c06/*" element={<C06 />} />
        <Route path="/c05" element={<C05 />} />
        <Route path="/me" element={<Me />} />
        <Route path="/s01" element={<S01 />} />
        <Route path="/m01" element={<M01 />} />
        <Route path="/m02" element={<M02 />} />
        <Route path="/m03" element={<M03 />} />
        <Route path="/m04" element={<M04 />} />
        <Route path="/m05" element={<M05 />} />
        <Route path="/screen/c02" element={<ScreenC02 />} />
        <Route path="*" element={<Home />} />
      </Routes>
      <GuidePanel />
    </div>
  )
}
